# Les Châtaigniers — site GitHub Pages

Site statique responsive prêt à être envoyé dans un dépôt GitHub Pages.

## Direction artistique

Le design mélange une ambiance de maison alsacienne traditionnelle et une présentation contemporaine :

- palette vert forêt, rouge profond, crème et bois ;
- rappels graphiques inspirés du colombage alsacien ;
- typographie serif élégante pour les titres ;
- cartes et boutons sobres, avec peu d'effets ;
- aucun effet « liquid glass » ni flou décoratif ;
- responsive mobile/tablette/ordinateur.

## Fichiers

- `index.html` — page principale
- `style.css` — design responsive
- `script.js` — menu mobile

## Mise en ligne sur GitHub Pages

1. Créer un dépôt GitHub.
2. Mettre ces fichiers à la racine du dépôt.
3. Aller dans **Settings → Pages**.
4. Choisir le déploiement depuis la branche principale (`main`) et le dossier `/ (root)`.
5. Enregistrer.

## Source des informations

Le contenu a été construit à partir du site public du Gîte Les Châtaigniers :
https://www.giteleschataigniers.fr/

Pages consultées :
- https://www.giteleschataigniers.fr/gite-les-chataigniers/
- https://www.giteleschataigniers.fr/tarif-resevation/
- https://www.giteleschataigniers.fr/galerie-photos/
- https://www.giteleschataigniers.fr/acces-breitenbach/
- https://www.giteleschataigniers.fr/a-voir-a-faire/
- https://www.giteleschataigniers.fr/contact/

Les photos actuellement utilisées dans le site pointent vers les ressources publiques du site source. Pour une version totalement autonome, les images pourront être copiées dans `assets/` avant la création du ZIP final.

Les tarifs et coordonnées sont ceux affichés sur les pages sources consultées ; ils doivent être vérifiés avant publication définitive.
